comment_id,user_id,comment_text,entry_time
1,5,Test comment.,
