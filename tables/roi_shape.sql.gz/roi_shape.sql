roi_shape_id	@path
