qwb_variant_id,qwd_word_id,text,lemma,grammar,meaning,type,commentary,qwb_biblio_id
