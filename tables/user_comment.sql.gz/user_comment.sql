comment_id¥user_id¥comment_text¥entry_time
1¥5¥Test comment.¥Sun May 21 2017 11:50:09 GMT+0200 (Central European Summer Time)
