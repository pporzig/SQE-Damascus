image_urls_id¥url¥suffix
0¥https://www.qumranica.org/cgi-bin/iipsrv.fcgi?IIIF=¥default.jpg
1¥http://gallica.bnf.fr/iiif/ark:/¥native.jpg
2¥http://192.114.7.208:8182/iiif/2/¥default.jpg
