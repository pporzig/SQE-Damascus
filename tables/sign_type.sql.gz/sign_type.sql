1	letter	\N
2	space	\N
3	possible vacat	\N
4	vacat	\N
5	damage	\N
6	blank line	\N
7	paragraph marker	\N
8	lacuna	\N
9	break	\N
