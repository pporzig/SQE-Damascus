attribute_id,name,type,description
1,sign_type,STRING,Type of char, e.g. a letter, a space, a place holder for a damaiged area and so on
2,break_type,STRING,Defines a Metasign as marking of line-, col-, and/or text break
3,width,NUMBER,The real width of a sign, only set, when != 1 and with a real sign
4,might_be_wider,BOOLEAN,Set to true if the width of the sign mght be wider than the given width
5,readability,STRING,The trad. DJD marking of readability, complete is not marked
6,is_reconstructed,BOOLEAN,true if the letter is totally reconstructed (brackets are not part of the sign stream!)
7,editorial_flag,STRING,Opinions of the editor like conjecture, additions...
8,correction,STRING,Correction marks added by a scribe
9,relative_position,STRING,Position relative to line context
